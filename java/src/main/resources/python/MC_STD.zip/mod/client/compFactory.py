
class EngineCompFactory:
    def CreateItem(self, entityId: str):
        pass